package com.estsoft.projectdose.admin.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PasswordResetRequest {
	private String password;
}