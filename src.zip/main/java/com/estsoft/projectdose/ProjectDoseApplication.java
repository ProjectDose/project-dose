package com.estsoft.projectdose;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectDoseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectDoseApplication.class, args);
	}

}
